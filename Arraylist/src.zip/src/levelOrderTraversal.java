import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Created by Sharath Nagendra on 7/6/2017.
 */
public class levelOrderTraversal {


    static class Node {
        int data;

        Node left;
        Node right;

        Node(int d) {
            this.data = d;

            this.right = null;
            this.left = null;
        }
    }





    public Node head;// head of linked list

    public levelOrderTraversal()
    {
        head = null;
    }
    /* Linked list node */



    public static  void traversal(Node startNode) {

        LinkedList<Node> queue = new LinkedList<Node>();
        queue.add(startNode);
        while(!queue.isEmpty()) {
            int levelNodes = queue.size();

            while (levelNodes > 0) {

                Node tempnode = queue.poll();

                System.out.println(tempnode.data);
                if (tempnode.left != null)
                    queue.add(tempnode.left);

                if (tempnode.right != null)
                    queue.add(tempnode.right);

                levelNodes--;

            }
            System.out.println("");
        }
    }





    public static void main(String[] args) {

        Node root = new Node(5);
        levelOrderTraversal lr = new levelOrderTraversal();

        root.left = new Node(10);
        root.right = new Node(15);
        root.left.left = new Node(20);
        root.left.right = new Node(25);
        root.right.left = new Node(30);
        root.right.right = new Node(35);
//        lr.head = new Node(1);
//        lr.head.left = new Node(2);
//        lr.head.right = new Node(3);
//        lr.head.left.left = new Node(4);
//        lr.head.left.right = new Node(5);

        traversal(root);


    }

}
