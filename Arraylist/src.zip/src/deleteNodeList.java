import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sharath Nagendra on 7/27/2017.
 */
public class deleteNodeList {
    static ListNode head;

    public static class ListNode {
        int val;
        ListNode next;

        ListNode(int x) {
            val = x;
        }
    }

    //function which displays the node at the nth position from the rear
    public static void deleteNode(int index) {
        int length = 0;
        ListNode temp = head;
        while (temp != null) {
            System.out.println(temp.val);
            temp = temp.next;
            length++;
        }
        if (length < index)
            return;
        // System.out.println(length);
        temp = head;
        //for nth element from first replace the condition in for loop: from i<length-index+1 to i<index
        for (int i = 1; i <  length -index+1 ; i++) {


            temp = temp.next;
        }


        System.out.println(index + "nd element from the last is " + temp.val);
    }

    public void push(int data) {
        ListNode node = new ListNode(data);
        node.next = head;
        head = node;

    }

    //function to delete nth node from the rear
    public static ListNode removeNthFromEnd(ListNode head, int n) {

        ListNode start = new ListNode(0);
        ListNode slow = start, fast = start;
        slow.next = head;

        //Move fast in front so that the gap between slow and fast becomes n
        for (int i = 1; i <= n + 1; i++) {
            fast = fast.next;
        }
        //Move fast to the end, maintaining the gap
        while (fast != null) {
            slow = slow.next;
            fast = fast.next;
        }
        //Skip the desired node
        slow.next = slow.next.next;
        return start.next;
    }

    public static void main(String[] args) {
        deleteNodeList obj = new deleteNodeList();

        obj.push(20);//last element
        obj.push(4);
        obj.push(15);
        obj.push(35);//first element

        ListNode x = new ListNode(1);
        x.next = new ListNode(2);
        x.next.next = new ListNode(3);
        x.next.next.next = new ListNode(4);
        x.next.next.next.next = new ListNode(5);

        int index = 5;
     //   System.out.println(removeNthFromEnd(x, index));
        deleteNode(index);
    }


}
