import java.util.HashMap;
import java.util.Map;

/**
 * Created by Sharath Nagendra on 8/18/2017.
 */
public class targetSum {
//print the pair which sums upto the target sum provided

    public static void checkPairs(int[] arr,int target){
        Map<Integer,Integer> mymap = new HashMap<Integer,Integer>();
        int[] newarr = new int[arr.length];
        for(int i=0;i<arr.length;i++){
            mymap.put(arr[i],target-arr[i]);
            if(mymap.containsKey(target-arr[i])){
                System.out.println("Matching pair is:"+ (target-arr[i])+", "+arr[i]);
            }
        }

    }


    public static void main(String[] args) {
        int[] arr = {1,2,4,5,8,12};
        int target = 12;
        checkPairs(arr,target);

    }
}
