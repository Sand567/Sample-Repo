import java.util.*;

/**
 * Created by Sharath Nagendra on 6/28/2017.
 */
public class find_duplicate_array {
    public static void main(String[] args) {


        int[] arr = new int[]{1, 2,2,5,5, 3, 3, 4, 5};

        Arrays.sort(arr);
        //regex to split the sting into values with commas
        String[] a = Arrays.toString(arr).split("[\\[\\]]")[1].split(", ");
        //  System.out.println(Arrays.toString(a));

        //regex to split string by removing the commas and start and end braces
        String fin = Arrays.toString(a).replaceAll("[\\[, \\]]", "");
        System.out.println(fin);
        String x = "sharath";
        hashtableDup(fin);
        // rev(x);

        // System.out.println(checkDuplicateUsingAdd(a));
        //    System.out.println("no dups");
//        else
//            System.out.println("dups present");
        // System.out.println(removeDuplicates(arr));

//
//        Map<String,String> map = new HashMap();
//
//        map.put("Father", "Rob");
//        map.put("Mother", "Kirsten");

        // map.remove("Mother");
    }


    //  System.out.println(Arrays.asList(map));


    public static void hashtableDup(String word) {

        char[] c = word.toCharArray();
        Map<Character, Integer> mymap = new HashMap<Character, Integer>();
        for (Character chars : c) {
            if (mymap.containsKey(chars)) {
                mymap.put(chars, mymap.get(chars) + 1);
            }
            else {
                mymap.put(chars, 1);
            }
        }


        Set<Map.Entry<Character, Integer>> entrySet = mymap.entrySet();
        for (Map.Entry<Character, Integer> entry : entrySet) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        }
    }

    public static void rev(String x) {
        String res = "";
        char c[] = x.toCharArray();
        for (int i = c.length - 1; i >= 0; i--)
            res = res + c[i];

        System.out.println(res);
    }

    public static boolean checkDuplicateUsingAdd(String[] input) {
        Set tempSet = new HashSet();
        for (String str : input) {
            if (!tempSet.add(str)) {

                return true;
            }
        }
        return false;
    }





    public static int removeDuplicates(int[] A) {
        int length = A.length;
        if (length == 0 || length == 1) return length;
        int i = 1;
        for (int j = 1; j < length; j++) {
            if (A[j] != A[j - 1]) {
                A[i] = A[j];
                i++;
            }
        }
        if (i < length) A[i] = '\0';
        return i;
    }
}
