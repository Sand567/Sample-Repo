import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 * Created by Sharath Nagendra on 7/31/2017.
 */
public class pathFromRootToNode {
    static Node root;
    static ArrayList<Integer> mylist = new ArrayList<>();

    static class Node {
        Node right;
        Node left;
        int data;

        public Node(int data) {
            right = null;
            left = null;
            this.data = data;
        }


    }

    public static int utilFun(Node node,int key){

        printPath(node,key);

        return mylist.size();

    }
    public static Boolean printPath(Node node, int key) {


        if (node == null)
            return false;
        if (node.data ==  key || printPath(node.left, key) || printPath(node.right, key)) {
            //   System.out.println("key found ");
            // System.out.println(node.data);
            mylist.add(node.data);
            return true;
        }
        return false;
    }

//    public static Boolean printPath(Node node, int key) {
//
//
//        if (node == null)
//            return false;
//        if (node.data == key || printPath(node.left, key) || printPath(node.right, key)) {
//            //   System.out.println("key found ");
//            // System.out.println(node.data);
//            mylist.add(node.data);
//            return true;
//        }
//        return false;
//    }

    public static void main(String[] args) {
        Node node = new Node(5);
        node.left = new Node(3);
        node.left.left = new Node(2);
        node.left.right = new Node(4);
        node.right = new Node(6);
        node.right.right = new Node(7);

       // printPath(node, 7);
        System.out.println(utilFun(node,7));
        // Collections.reverse(mylist);
       // System.out.println(mylist);
      //  System.out.println(mylist.size());
    }
}
