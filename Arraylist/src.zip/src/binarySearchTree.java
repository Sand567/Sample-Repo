import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Created by Sharath Nagendra on 7/7/2017.
 */
public class binarySearchTree {

    static Node root;

    static class Node {
        Node right;
        Node left;
        int data;

        public Node(int data) {
            right = null;
            left = null;
            this.data = data;
        }


    }

    binarySearchTree() {
        root = null;
    }

    public void insert(int data) {

        root = InsRecord(root, data);

    }

    public Node InsRecord(Node root, int data) {

        if (root == null) {
            root = new Node(data);
            return root;
        } else if (data < root.data)
            root.left = InsRecord(root.left, data);


        else if (data > root.data)
            root.right = InsRecord(root.right, data);


        return root;

    }

    public int size(Node root) {

        if (root == null)
            return 0;
        else
            return (size(root.left) + 1 + size(root.right));
    }

    public void inorderTraversal() {


        inorder(root);
    }


    public static void inorder(Node root) {

        if (root != null) {
            inorder(root.left);

            System.out.println(root.data);

            inorder(root.right);
        }

    }


    public static void preorder(Node root) {

        if (root != null) {
            System.out.println(root.data);
            inorder(root.left);
            inorder(root.right);
        }

    }


    //function to delete a node given the node and key
    public static Node deleteNode(Node node, int key) {

        if (node == null) {
            return null;
        }
        if (key < node.data) {
            node.left = deleteNode(node.left, key);
        } else if (key > node.data) {
            node.right = deleteNode(node.right, key);
        } else {
            if (node.left == null) {
                return node.right;
            } else if (node.right == null) {
                return node.left;
            }
            Node x = findMin(node.right);
            node.data = x.data;
            node.right = deleteNode(node.right, node.data);
        }
        return node;
    }


    //function to find min
    public static Node findMin(Node node) {

        while (node.left != null) {
            node = node.left;
        }

        return node;
    }

    //iterative tree traversal as opposed to recursive

    public static List<Integer> search(Node node) {

        List<Integer> list = new ArrayList<Integer>();
        Stack<Node> stack = new Stack<Node>();
        Node cur = node;
        while (cur != null || !stack.empty()) {
            while (cur != null) {
                stack.add(cur);
                cur = cur.left;
            }
            cur = stack.pop();
            list.add(cur.data);
            System.out.println(cur.data);
            cur = cur.right;
        }
        return list;
    }


    //print all nodes at given level

    static void printKDistant(Node node, int k) {
        if (node == null)
            return;
        if (k == 0) {
            System.out.print(node.data + " ");
            return;
        } else {
            printKDistant(node.left, k - 1);
            printKDistant(node.right, k - 1);
        }
    }

    //RECURSION -----------------------------print all leaf nodes
    public static void printLeaf(Node node) {
        if (node == null)
            return;
        if (node.left == null && node.right == null)
            System.out.println(node.data);
        printLeaf(node.left);
        printLeaf(node.right);
    }


    //ITERATION------------------------print all leaf nodes
    public static void iterativePrintLeaf(Node newNode){
        if(newNode ==null){
            return;
        }

        Stack<Node> stack = new Stack<>();
        stack.push(newNode);
        while(!stack.isEmpty()){

            Node node = stack.pop();
            if(node.right!=null)
            {
                stack.push(node.right);
            }
            if(node.left!=null){
                stack.push(node.left);

            }

            if(node.left==null && node.right ==null){
                System.out.println(node.data);
            }
        }
    }
    // 50 30 20 40  70 60 80
    public static void main(String[] args) {
        binarySearchTree tree = new binarySearchTree();
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        Node node = new Node(5);
        node.left = new Node(3);
        node.left.left = new Node(2);
        node.left.right = new Node(4);
        node.right = new Node(6);
        node.right.right = new Node(7);


        Node newNode = new Node(1);
        newNode.left = null;
        newNode.right = new Node(2);
        newNode.right.left = new Node(3);
        newNode.right.right = null;
        //delete a node
      //  Node res = deleteNode(node, 3);

        //   preorder(res);


        //iterative binary search traversal
      //  search(node);

        //print elements of tree
        //tree.inorderTraversal();

        //print all nodes at a given level
      //  printKDistant(node, 2);


        //print leaf nodes RECURSION
       // printLeaf(node);

        //print leaf nodes ITERATIVE
        iterativePrintLeaf(node);
    }


}
