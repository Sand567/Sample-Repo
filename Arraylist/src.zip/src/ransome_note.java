import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by Sharath Nagendra on 7/1/2017.
 */
public class ransome_note {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int m = in.nextInt();
        int n = in.nextInt();
        String magazine[] = new String[m];
        for (int magazine_i = 0; magazine_i < m; magazine_i++) {
            magazine[magazine_i] = in.next();
        }
        String ransom[] = new String[n];
        for (int ransom_i = 0; ransom_i < n; ransom_i++) {
            ransom[ransom_i] = in.next();
        }

        System.out.println(ransomNoteFunction(ransom, magazine));

    }








    public static boolean ransomNoteFunction(String[] ransom, String[] magazine) {
//        int[] arr = new int[26];
//
        String ransomString = Arrays.toString(ransom);
        String magazineString = Arrays.toString(magazine);
//        if (ransomString.length() > magazineString.length()) return false;
////        for (int i = 0; i < magazineString.length(); i++)
////            arr[magazineString.charAt(i) - 'a']++;
////
////        for (int i = 0; i < ransomString.length(); i++) {
////            if (--arr[ransomString.charAt(i) - 'a']< 0) {
////                return false;
////            }
////        }
////        //System.out.println(ransomString);
////        return true;
//
//
//        char[] mc = magazineString.toCharArray(), rc = ransomString.toCharArray();
//        int[] map = new int[256];
//        for(char c: mc){
//            map[c]++;
//        }
//
//        for(char c: rc){
//            if(--map[c] < 0) return false;
//        }
//        return true;
        Map<Character, Integer> magM = new HashMap<>();
        for (char c:magazineString.toCharArray()){
            int newCount = magM.getOrDefault(c, 0)+1;
            magM.put(c, newCount);
        }
        for (char c:ransomString.toCharArray()){
            int newCount = magM.getOrDefault(c,0)-1;
            if (newCount<0)
                return false;
            magM.put(c, newCount);
        }
        return true;

    }
}
//
//    public static boolean ransomNoteFunction(String[] ransom, String[] magazine)
//    {
//
//        Map<Character,Integer> mymap = new HashMap<Character,Integer>();
//        String magazineString = Arrays.toString(magazine);
//     //   System.out.println(magazineString);
//        String ransomString = Arrays.toString(ransom);
//        for(int i=0;i<magazine.length;i++)
//        {
//            Character cur = magazineString.charAt(i);
//            Integer numtimes = mymap.get(cur);
//            if(numtimes ==null)
//            {
//                mymap.put(cur,1);
//                continue;
//            }
//            mymap.put(cur,numtimes++);
//
//        }
//
//        for(int i =0;i<ransom.length;i++)
//        {
//            Character cur = ransomString.charAt(i);
//            Integer numtimes = mymap.get(cur);
//            if(numtimes == null )
//            {
//                return  false;
//
//            }
//            mymap.put(cur,numtimes--);
//        }
//
//return  true;
//    }
//



