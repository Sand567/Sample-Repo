import java.util.Arrays;

class Threads {

    public static int majorityElement(int[] num) {

        int major = num[0], count = 1;
        for (int i = 1; i < num.length; i++) {
            if (count == 0) {
                count++;
                major = num[i];
            } else if (major == num[i]) {
                count++;
            } else count--;

        }
        return major;
    }

    public static void main(String[] args) {
        int[] num={1,5,2,4,5,4,2,2,2,4};
       // Arrays.sort(num);

        //System.out.println(num[num.length/2]);

        int count = 1, max = 1;

        for (int i = 1; i < num.length; i++) {
            if (num[i] >= num[i - 1]) {
                count++;
            } else {
                count = 1;
            }

            if (count > max) {
                max = count;
            }
        }

        System.out.println(max);

        //return nums[nums.length/2];
      //  System.out.println(majorityElement(num));
    }

}